package example.practice.greet.server;

import com.proto.greet.*;
import com.proto.greet.GreetServiceGrpc.GreetServiceImplBase;
import io.grpc.Context;
import io.grpc.stub.StreamObserver;

public class GreetServiceImpl extends GreetServiceImplBase {
    @Override
    public void greet(GreetRequest request, StreamObserver<GreetResponse> responseObserver) {

        // Extract the fields that we need.
       Greet greeting = request.getGreeting();
       String name = greeting.getFirstName();

       // Create the response.
       String result = "Hello "+ name;
       GreetResponse greetResponse = GreetResponse.newBuilder()
               .setResult(result).build();

       // Send the response.
       responseObserver.onNext(greetResponse);

       // Complete the RPC call.
       responseObserver.onCompleted();
    }

    @Override
    public void greetManyTimes(GreetManyTimesRequest request, StreamObserver<GreetManyTimesResponse> responseObserver) {
        // Extract the fields that we need.
        Greet greeting = request.getGreeting();
        String name = greeting.getFirstName();
        try{
            for(int i=0 ; i<10; i++) {
                String result = "Hello " + name + " ,response number: " + i;
                GreetManyTimesResponse greetManyTimesResponse = GreetManyTimesResponse.newBuilder()
                        .setResult(result)
                        .build();
                responseObserver.onNext(greetManyTimesResponse);
                Thread.sleep(1000L);
            }
        }catch (InterruptedException e){
            e.printStackTrace();
        }finally {
            responseObserver.onCompleted();
        }
    }

    @Override
    public StreamObserver<LongGreetRequest> longGreet(StreamObserver<LongGreetResponse> responseObserver) {
        StreamObserver<LongGreetRequest> streamObserver = new StreamObserver<LongGreetRequest>() {
            String result = "";
            @Override
            public void onNext(LongGreetRequest value) {
            // Client sends a message.
                result+="Hello "+value.getGreeting().getFirstName()+"! ";
            }

            @Override
            public void onError(Throwable t) {
            // Client sends an error.
            }

            @Override
            public void onCompleted() {
            // Client is done.
            // This is when we want to return a response (ResponseObserver.)
                responseObserver.onNext(LongGreetResponse.newBuilder()
                                                         .setResult(result)
                                                         .build());
                responseObserver.onCompleted();
            }
        };
        return streamObserver;
    }

    @Override
    public StreamObserver<GreetEveryoneRequest> greetEveryone(StreamObserver<GreetEveryoneResponse> responseObserver) {

        StreamObserver<GreetEveryoneRequest> requestStreamObserver = new StreamObserver<GreetEveryoneRequest>() {
            @Override
            public void onNext(GreetEveryoneRequest value) {
                String result = "Hello "+value.getGreeting().getFirstName();
                GreetEveryoneResponse greetEveryoneResponse = GreetEveryoneResponse.newBuilder().setResult(result).build();

                responseObserver.onNext(greetEveryoneResponse);
            }

            @Override
            public void onError(Throwable t) {

            }

            @Override
            public void onCompleted() {
                // When client says, I am done sending data, server can respond the same that he is done sending data.
               responseObserver.onCompleted();
            }
        };
        return requestStreamObserver;
    }

    @Override
    public void greetWithDeadline(GreetWithDeadlineRequest request, StreamObserver<GreetWithDeadlineResponse> responseObserver) {
        Context current = Context.current();
     try {
         for (int i = 0; i < 3; i++) {
             if(!current.isCancelled()) {
                 System.out.println("Sleep for 100 ms.");
                 Thread.sleep(100);
             }else {
                 return;
             }
         }
         System.out.println("Sends a response.");
         responseObserver.onNext(GreetWithDeadlineResponse.newBuilder()
                 .setResult("Hello " + request.getGreeting().getFirstName()).build());
         responseObserver.onCompleted();
     }catch (InterruptedException e){
         e.printStackTrace();
     }
    }
}
