package example.practice.calculator.client;

import com.proto.calculator.CalculatorServiceGrpc;
import com.proto.calculator.SquareRootRequest;
import com.proto.greet.*;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;

import java.util.Arrays;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

public class CalculatorClient {
    public static void main(String[] args) throws InterruptedException {
        System.out.println("Hello I am a gRPC Calculator Client");

        runClient();
    }

    private static void runClient() throws InterruptedException {
        ManagedChannel channel = ManagedChannelBuilder.forAddress("localhost",50051)
                .usePlaintext()
                .build();

        doSquareErrorCall(channel);

        System.out.println("Shutting down channel");
        channel.shutdown();
    }

    private static void doSquareErrorCall(ManagedChannel channel) {
        CalculatorServiceGrpc.CalculatorServiceBlockingStub blockingStub = CalculatorServiceGrpc.newBlockingStub(channel);
        int number = -1;
        try {
            blockingStub.squareRoot(SquareRootRequest.newBuilder()
                    .setNumber(number).build());
        }catch (StatusRuntimeException e){
            System.out.println("Got an exception fo square root!");
            e.printStackTrace();
        }
    }
}
