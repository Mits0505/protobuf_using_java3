package example.practice.calculator.server;

import io.grpc.Server;
import io.grpc.ServerBuilder;
import io.grpc.protobuf.services.ProtoReflectionService;

import java.io.IOException;

public class CalculatorServer {
    public static void main(String[] args) throws IOException, InterruptedException {
        System.out.println("Hello Calculator Server!");

        Server server = ServerBuilder.forPort(50051)
                                     .addService(new CalculatorServiceImpl())
                                     // It will enable reflection and will reflect any of the service that was added before.
                                     .addService(ProtoReflectionService.newInstance())  // for reflection.
                                     .build();
        server.start();

        /* With the help of below code, when we try to close the application, server
         * will also shutdown. And server.awaitTermination() will complete.
         */

        Runtime.getRuntime().addShutdownHook(new Thread( () -> {
         System.out.println("Recieved Shutdown Request..");
         server.shutdown();
         System.out.println("Successfully stopped the server.");
        }));

        // In gRPC, this server needs to be blocking for the main thread, so we do server.awaitTermination().
        server.awaitTermination(); // If we don't do this, then our server will start and program will finish.
    }
}
